Implementación de la Práctica 1 (Shopping1) en el esqueleto que se le da a los alumnos
